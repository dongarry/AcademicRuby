
require 'test/unit'
require_relative 'TC_Card.rb'
require_relative 'TC_Deck.rb'
require_relative 'TC_Hand.rb'
require_relative 'TC_SuperReport.rb'