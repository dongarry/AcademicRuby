class Deck_check

  def check_card_count?(no_of_cards)
    if no_of_cards==52
      #puts "This deck has the correct number of cards"
      TRUE
    else
      FALSE
    end
  end

end