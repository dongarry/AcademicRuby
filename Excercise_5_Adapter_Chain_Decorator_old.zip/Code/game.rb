
class Poker_composition

  def poker_deck
    Deck.new
  end
  def poker_pile
      Pile.new
  end
  def poker_pile
      Pile.new
  end
end
